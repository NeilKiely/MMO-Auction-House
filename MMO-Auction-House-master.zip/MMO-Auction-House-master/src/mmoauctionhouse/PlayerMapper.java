/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mmoauctionhouse;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

/**
 *
 * @author Chris Mulcahy
 */
public class PlayerMapper {
    
    public static Player getPlayer(String username) {
        File playersFile = new File("resources/players.txt");
        String[] playerInfoArr = new String[0];
        boolean foundPlayer = false;
        Player player = null;
        
        String[] itemsArr = readPlayerInventory(username);
        for (int i = 0; i < itemsArr.length; i++)
        {
                System.out.println(itemsArr[i]);
        }
        Inventory inv = new Inventory(itemsArr);
        
        IFile iFile = IFileFactory.getIFile("SCFile");
        iFile.get(playersFile.getAbsolutePath());
        String [][] playerDetails = iFile.read();
        
        for (int i =0;  i< playerDetails.length; i++)
        {
            if (playerDetails[i][0].equals(username))
            {
                foundPlayer = true;
                playerInfoArr = new String[playerDetails[i].length];
                playerInfoArr = playerDetails[i];
            }
        }
        switch (playerInfoArr[1]) {
            case "Bronze":
                player = (Player) new Bronze(playerInfoArr[1], Double.parseDouble(playerInfoArr[2]), Integer.parseInt(playerInfoArr[3]), inv, username);
                break;
            case "Silver":
                player = (Player) new Silver(playerInfoArr[1], Double.parseDouble(playerInfoArr[2]), Integer.parseInt(playerInfoArr[3]), inv, username);
                break;
            case "Gold":
                player = (Player) new Gold(playerInfoArr[1], Double.parseDouble(playerInfoArr[2]), Integer.parseInt(playerInfoArr[3]), inv, username);
                break;
            default:
                player = (Player) new Bronze("ERROR_USERNAME", 90.0, 0, inv, username);
        }
        return player;
    }
    
    private static String[] readPlayerInventory(String username) {
        File playersFile = new File("resources/players.txt");
        String[] itemArr = new String[0];
        boolean foundPlayer = false;
        
        IFile iFile = IFileFactory.getIFile("SCFile");
        iFile.get(playersFile.getAbsolutePath());
        String [][] playerInventory = iFile.read();
        
        for (int i = 0; i < playerInventory.length && !foundPlayer; i++)
        {
            if (playerInventory[i][0].equals(username))
            {
                foundPlayer = true;
                System.out.println("Found user");
                int numItems = Integer.parseInt(playerInventory[i][4]);
                itemArr = new String[numItems];
                
                for (int j = 0; j < numItems; j++)
                {
                    String itemDetails = "";
                    for (int k = 0; k < playerInventory[i+j+1].length; k++)
                    {
                        itemDetails += playerInventory[i+j+1][k] + iFile.getDelimiter(); 
                    }
                    itemDetails = itemDetails.substring(0, itemDetails.length() - 1);
                    itemArr[j] = itemDetails;
                }
            }
        }
        return itemArr;
    }
}
