
package mmoauctionhouse;

/**
 *
 * @author Vilius
 */
public class User {
    
}
